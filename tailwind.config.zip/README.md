
# Soporte24hs Ayuda — Astro (Light Theme) v2
- Home vistosa con imágenes.
- Menú superior y categorías.
- Multi-país (AR/MX/ES).
- Sección Ayuda + buscador.
- Artículos ejemplo con FAQ JSON-LD y CTA USD 5.
- Páginas legales y contacto.
- SEO técnico: canonical, hreflang, sitemap, robots.

## Scripts
npm i
npm run dev
npm run build
npm run preview
