// src/data/giftCardsData.js
// 10 países — un (1) producto por país (Netflix). Incluye seoNote para contenido único por país.

export const giftCardsData = {
  ar: {
    slug: "netflix-argentina",
    brand: "Netflix",
    country: "Argentina",
    flag: "🇦🇷",
    badge: "/ai/netflix-argentina-badge.png",
    currency: "ARS",
    symbol: "$",
    locale: "es-AR",
    fx: 1300, // 1 USD ≈ 1300 ARS (referencia visual)
    baseUSD1: 12.0,
    baseUSD3: 24.0,
    baseUSD6: 40.0,
    redeemUrl: "https://www.netflix.com/ar/redeem",
    title: "Netflix Gift Card Argentina — Comprá online y canjeá fácil",
    description:
      "Comprá tu Netflix Gift Card Argentina 100% digital. Pagá con transferencia, PayPal o criptomonedas y recibí tu código por email dentro de 24hs. Canjeá en netflix.com/ar/redeem.",
    seoNote:
      "En Argentina priorizamos pagos por transferencia en ARS. Si querés, también podés pagar en USD por PayPal o cripto de forma opcional."
  },

  cl: {
    slug: "netflix-chile",
    brand: "Netflix",
    country: "Chile",
    flag: "🇨🇱",
    badge: "/ai/netflix-argentina-badge.png",
    currency: "CLP",
    symbol: "$",
    locale: "es-CL",
    fx: 970,
    baseUSD1: 12.0,
    baseUSD3: 24.0,
    baseUSD6: 40.0,
    redeemUrl: "https://www.netflix.com/cl/redeem",
    title: "Netflix Gift Card Chile — Compra y canjea al instante",
    description:
      "Compra tu Netflix Gift Card Chile y recibe tu código por correo electrónico. Pagá en USD vía PayPal o cripto y activá tu cuenta fácilmente en netflix.com/cl/redeem.",
    seoNote:
      "Ideal si no querés usar tarjeta en Chile. Te enviamos el código digital y lo canjeás en segundos con tu cuenta actual."
  },

  uy: {
    slug: "netflix-uruguay",
    brand: "Netflix",
    country: "Uruguay",
    flag: "🇺🇾",
    badge: "/ai/netflix-argentina-badge.png",
    currency: "UYU",
    symbol: "$",
    locale: "es-UY",
    fx: 43,
    baseUSD1: 12.0,
    baseUSD3: 24.0,
    baseUSD6: 40.0,
    redeemUrl: "https://www.netflix.com/uy/redeem",
    title: "Netflix Gift Card Uruguay — Regalá entretenimiento",
    description:
      "Compra tu Netflix Gift Card Uruguay en minutos. Recibí el código por email y canjealo en netflix.com/uy/redeem. Pagá seguro con PayPal o criptomonedas.",
    seoNote:
      "Opción práctica para regalar en Uruguay: envío por email, canje inmediato y sin necesidad de tarjeta de crédito."
  },

  bo: {
    slug: "netflix-bolivia",
    brand: "Netflix",
    country: "Bolivia",
    flag: "🇧🇴",
    badge: "/ai/netflix-argentina-badge.png",
    currency: "BOB",
    symbol: "Bs ",
    locale: "es-BO",
    fx: 6.9,
    baseUSD1: 12.0,
    baseUSD3: 24.0,
    baseUSD6: 40.0,
    redeemUrl: "https://www.netflix.com/bo/redeem",
    title: "Netflix Gift Card Bolivia — Códigos digitales instantáneos",
    description:
      "Comprá tu Netflix Gift Card Bolivia 100% digital. Pagá en USD con PayPal o cripto y recibí tu código en 24hs. Activala fácilmente en netflix.com/bo/redeem.",
    seoNote:
      "Funciona para cuentas nuevas o existentes en Bolivia. Cargás tu saldo y controlás tu suscripción sin tarjeta."
  },

  mx: {
    slug: "netflix-mexico",
    brand: "Netflix",
    country: "México",
    flag: "🇲🇽",
    badge: "/ai/netflix-argentina-badge.png",
    currency: "MXN",
    symbol: "$",
    locale: "es-MX",
    fx: 19,
    baseUSD1: 12.0,
    baseUSD3: 24.0,
    baseUSD6: 40.0,
    redeemUrl: "https://www.netflix.com/mx/redeem",
    title: "Netflix Gift Card México — Canjea en segundos",
    description:
      "Compra tu Netflix Gift Card México online. Recibe el código por email y canjéalo al instante en netflix.com/mx/redeem. Pago seguro con PayPal o criptomonedas.",
    seoNote:
      "Excelente alternativa en México para mantener Netflix Premium sin tarjeta. Canje rápido y soporte por email."
  },

  pe: {
    slug: "netflix-peru",
    brand: "Netflix",
    country: "Perú",
    flag: "🇵🇪",
    badge: "/ai/netflix-argentina-badge.png",
    currency: "PEN",
    symbol: "S/",
    locale: "es-PE",
    fx: 3.7,
    baseUSD1: 12.0,
    baseUSD3: 24.0,
    baseUSD6: 40.0,
    redeemUrl: "https://www.netflix.com/pe/redeem",
    title: "Netflix Gift Card Perú — Rápido y seguro",
    description:
      "Compra tu Netflix Gift Card Perú y recibe tu código digital al instante. Pagá en USD por PayPal o criptomonedas. Actívala en netflix.com/pe/redeem.",
    seoNote:
      "Si estás en Perú y no querés usar tarjeta, la gift card es la forma más simple de pagar Netflix mes a mes."
  },

  co: {
    slug: "netflix-colombia",
    brand: "Netflix",
    country: "Colombia",
    flag: "🇨🇴",
    badge: "/ai/netflix-argentina-badge.png",
    currency: "COP",
    symbol: "$",
    locale: "es-CO",
    fx: 4100,
    baseUSD1: 12.0,
    baseUSD3: 24.0,
    baseUSD6: 40.0,
    redeemUrl: "https://www.netflix.com/co/redeem",
    title: "Netflix Gift Card Colombia — Suscripción fácil y digital",
    description:
      "Compra tu Netflix Gift Card Colombia online. Recibí tu código por correo electrónico y canjealo en netflix.com/co/redeem. Pagá con PayPal o cripto sin tarjeta.",
    seoNote:
      "Útil en Colombia para controlar el gasto mensual. Cargás saldo cuando querés y evitás rechazos de tarjeta."
  },

  ec: {
    slug: "netflix-ecuador",
    brand: "Netflix",
    country: "Ecuador",
    flag: "🇪🇨",
    badge: "/ai/netflix-argentina-badge.png",
    currency: "USD",
    symbol: "$",
    locale: "es-EC",
    fx: 1, // dólarizado
    baseUSD1: 12.0,
    baseUSD3: 24.0,
    baseUSD6: 40.0,
    redeemUrl: "https://www.netflix.com/ec/redeem",
    title: "Netflix Gift Card Ecuador — Pago digital instantáneo",
    description:
      "Compra tu Netflix Gift Card Ecuador sin complicaciones. Recibí tu código por email y canjealo al instante en netflix.com/ec/redeem.",
    seoNote:
      "Al estar dolarizado, el cobro en USD te resulta directo. Enviamos el código por email y listo."
  },

  py: {
    slug: "netflix-paraguay",
    brand: "Netflix",
    country: "Paraguay",
    flag: "🇵🇾",
    badge: "/ai/netflix-argentina-badge.png",
    currency: "PYG",
    symbol: "₲",
    locale: "es-PY",
    fx: 7400,
    baseUSD1: 12.0,
    baseUSD3: 24.0,
    baseUSD6: 40.0,
    redeemUrl: "https://www.netflix.com/py/redeem",
    title: "Netflix Gift Card Paraguay — Canjea rápido y fácil",
    description:
      "Compra tu Netflix Gift Card Paraguay 100% online. Recibe el código por email y canjealo en netflix.com/py/redeem. Pago seguro vía PayPal o cripto.",
    seoNote:
      "Recomendado para regalar en Paraguay. Código digital, canje inmediato y soporte por correo."
  },

  cr: {
    slug: "netflix-costa-rica",
    brand: "Netflix",
    country: "Costa Rica",
    flag: "🇨🇷",
    badge: "/ai/netflix-argentina-badge.png",
    currency: "CRC",
    symbol: "₡",
    locale: "es-CR",
    fx: 520,
    baseUSD1: 12.0,
    baseUSD3: 24.0,
    baseUSD6: 40.0,
    redeemUrl: "https://www.netflix.com/cr/redeem",
    title: "Netflix Gift Card Costa Rica — Regala entretenimiento",
    description:
      "Compra tu Netflix Gift Card Costa Rica fácilmente. Recibí el código digital y activá tu cuenta en netflix.com/cr/redeem. Pago seguro en USD.",
    seoNote:
      "En Costa Rica resolvés tu suscripción con un código prepago. Recibís el correo y canjeás en minutos."
  },
};


