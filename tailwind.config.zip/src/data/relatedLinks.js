export const relatedLinks = (countryCode) => {
  const countryBase = `/gift-cards/${countryCode}/`;
  const helpGuide = `/${countryCode}/ayuda/como-pagar-netflix-con-gift-card/`; // ajustá si tu estructura de ayuda cambia
  return {
    moreInCountry: { href: countryBase, text: "Gift Cards disponibles en " },
    helpGuide: { href: helpGuide, text: "guía para pagar Netflix con Gift Card" },
  };
};
