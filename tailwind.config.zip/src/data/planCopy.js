export const planFeatures = [
  "✅ Series y películas en HD/4K (según tu plan)",
  "✅ Entrega del código por email dentro de 24 horas",
  "✅ Garantía de recepción",
  "✅ En caso de no contar con stock recibis una suscripción activa",
  "✅ Pagá con Transferencia / PayPal / Cripto (USDT, BTC, etc.)"
];
