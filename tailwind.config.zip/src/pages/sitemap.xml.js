// src/pages/sitemap.xml.js
// Si usás TS, podés hacer sitemap.xml.ts con el mismo contenido tipado.
import { giftCardsData } from "../data/giftCardsData.js";

export const prerender = true;

const SITE = "https://soporte24hs.com"; // <-- Cambiá aquí si usás otro dominio en dev

export async function GET() {
  // Páginas base (home, listados, etc.)
  const baseUrls = [
    `${SITE}/`,
    `${SITE}/gift-cards/`,
    `${SITE}/ayuda/`,
    // Agregá otras secciones globales si las tenés:
    // `${SITE}/contacto/`, `${SITE}/terminos/`, etc.
  ];

  // Gift cards por país/slug a partir de tu data
  const giftUrls = Object.entries(giftCardsData)
    .flatMap(([pais, cfg]) => {
      if (!cfg) return [];
      // si cfg es un objeto con .slug
      if (cfg.slug) {
        return [`${SITE}/gift-cards/${pais}/${cfg.slug}/`];
      }
      // si cfg es una lista de items por país
      if (Array.isArray(cfg)) {
        return cfg
          .filter(Boolean)
          .map(item => `${SITE}/gift-cards/${pais}/${item.slug}/`);
      }
      return [];
    });

  const urls = [...new Set([...baseUrls, ...giftUrls])];

  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="https://www.sitemaps.org/schemas/sitemap/0.9">
  ${urls
    .map(
      (u) => `<url>
    <loc>${u}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>${u === SITE + "/" ? "1.0" : "0.8"}</priority>
  </url>`
    )
    .join("\n")}
</urlset>`;

  return new Response(xml, {
    headers: {
      "Content-Type": "application/xml",
      // cachea 1 día en edge/CDN
      "Cache-Control": "public, max-age=0, s-maxage=86400",
    },
  });
}
